
import React from "react"
import {View,Button,Dimensions} from "react-native"
import {OvalButton} from "../components/ButtonGroup"
import {connect}  from "react-redux"
import Icon from 'react-native-vector-icons/FontAwesome';
import MapView, { PROVIDER_GOOGLE } from 'react-native-maps';
const dims = Dimensions.get('window')
class DriverMap extends React.Component{
    render(){
        // return <View>
        //     {/* { <View style ={{
        //             position:'absolute',
        //             top:20,
        //             left:20,
        //             zIndex:100
        //         }}>
            
        //           {  <OvalButton size={50} onPress={
        //                 ()=>this.props.navigation.toggleDrawer()
        //             } bg="#fff" >
        //                 <Icon name="bars" color="#000" size={20}/>
        //             </OvalButton> 
            
        //         </View> */}
        //      }
        return <View style ={{
                        width:dims.width,
                        height:dims.height,
                        justifyContent: 'flex-end',
                        alignItems: 'center'}}>
                            <MapView
                            provider={PROVIDER_GOOGLE}
                            style ={{
                                width:dims.width,
                                height:dims.height,
                                justifyContent: 'flex-end',
                                alignItems: 'center'
                            }}
                                    region={{
                                latitude: 28.7041,
                                longitude: 77.1025,
                                latitudeDelta: 0.015,
                                longitudeDelta: 0.0121,
                            }}
                            >
                            </MapView>
        
            { <View style ={{
                    position:'absolute',
                     top:15,
                    left:15,
                    zIndex:100
                }}>
            
                  {<OvalButton size={40} onPress={
                        ()=>this.props.navigation.toggleDrawer()
                    } bg="#fff" >
                        <Icon name="bars" color="#000" size={17}/>
                    </OvalButton> }
            
                </View> 
                }
        
      </View>
   
    }
}

const mapState = (state) => {
    return {
        network:state.network
    }
}


export default connect(mapState)(DriverMap)